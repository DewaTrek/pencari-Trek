/* ==========================================================================
   FILE NAME: scanner.js
   VERSION: 13.0 (MATRIX JUMP EDITION)
   AUTHOR: GEMINI AI PARTNER & KIKI
   
   UPGRADE LOGIKA:
   1. AI JUMPING: Angka AI tidak lagi berurutan, tapi lompat acak (Matriks).
   2. FIX CB 4D & AI 1 DIGIT (Sudah tertanam aman).
   3. LOGIKA V11 (Normal/Rebound/Ekstrim) TETAP AKTIF.
   ========================================================================== */

// --- VARIABEL KONTROL ---
let isAutoRunning = false;   
let globalBestAcc = -1;      
let globalBestWinCount = 0; 
let currentStrategy = 'NORMAL'; 

// --- VARIABEL AUTO SORTIR (BARU) ---
let isMultiRunning = false;
let multiTargetQueue = [];     
let multiCollected = [];       
let multiResults = [];         
let currentMultiIdx = 0;

let finalRekapData = {}; // KHUSUS PENAMPUNG KEPALA EKOR

// [BARU] DAFTAR HITAM SEMENTARA (Agar Rumus Tidak Kembar Terus)
let recentWinners = []; // Menyimpan rumus yang barusan menang
const MAX_MEMORY = 1000;   // Berapa lama rumus dilarang muncul lagi (misal 5 kali scan)

// --- VARIABEL VOTING & ALARM (BARU) ---
let isVotingActive = false;
let votingData = {}; 
let alarmSound = new Audio("https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg"); 
alarmSound.loop = true;

// ==========================================================================
// 1. DATABASE ANGKA & MATRIKS (JANTUNG SYSTEM)
// ==========================================================================
const SHIO_DATA = {
    1: [1, 13, 25, 37, 49, 61, 73, 85, 97],
    2: [2, 14, 26, 38, 50, 62, 74, 86, 98],
    3: [3, 15, 27, 39, 51, 63, 75, 87, 99],
    4: [4, 16, 28, 40, 52, 64, 76, 88, 0], 
    5: [5, 17, 29, 41, 53, 65, 77, 89],
    6: [6, 18, 30, 42, 54, 66, 78, 90],
    7: [7, 19, 31, 43, 55, 67, 79, 91],
    8: [8, 20, 32, 44, 56, 68, 80, 92],
    9: [9, 21, 33, 45, 57, 69, 81, 93],
    10: [10, 22, 34, 46, 58, 70, 82, 94],
    11: [11, 23, 35, 47, 59, 71, 83, 95],
    12: [12, 24, 36, 48, 60, 72, 84, 96]
};

// --- LOGIKA MISTIK ---
const MISTIK_LAMA = [1, 0, 5, 8, 7, 2, 9, 4, 3, 6]; 
const MISTIK_BARU = [8, 7, 6, 9, 5, 4, 2, 1, 0, 3];
const INDEX_DATA  = [5, 6, 7, 8, 9, 0, 1, 2, 3, 4];
const TAYSEN_DATA = [7, 4, 9, 6, 1, 8, 3, 0, 5, 2];

// --- MATRIKS LOMPAT (RAHASIA AI JITU) ---
// Ini yang bikin angka AI tidak berurutan lagi.
// Pola +7 (Coprime 10) -> Menghasilkan sebaran angka paling acak tapi merata.
const MATRIX_LOMPAT = [0, 7, 4, 1, 8, 5, 2, 9, 6, 3];

// ==========================================================================
// 2. GENERATOR POLA
// ==========================================================================
function generatePatterns() {
    let formulas = [];
    const parts = ['A', 'C', 'K', 'E']; 
    const days = ['1', '2', '3']; 
    const wrappers = ['', '', '', 'ML', 'MB', 'IDX', 'TYS']; 
    
    // A. POLA DASAR
    for(let p1 of parts) {
        for(let p2 of parts) {
            for(let d1 of days) {
                for(let d2 of days) {
                    formulas.push(`${p1}${d1} + ${p2}${d2}`);
                    formulas.push(`${p1}${d1} - ${p2}${d2}`);
                    formulas.push(`(${p1}${d1} + ${p2}${d2}) * 2`);
                    formulas.push(`ML(${p1}${d1}) + ${p2}${d2}`);
                    formulas.push(`IDX(${p1}${d1}) - ${p2}${d2}`);
                }
            }
        }
    }

    // B. DEEP MINING (MODE MONSTER: CARI 100% PERFECT FIT)
    const partsExtended = ['A', 'C', 'K', 'E'];
    const daysExtended = ['1', '2', '3', '4', '5', '6']; 
    const operators = ['+', '-', '+', '-', '*']; // Perbanyak operator
    
    // UBAH 1: NAIKKAN JUMLAH LOOP (Biar makin keras usahanya cari yang 100%)
    // Dulu 3500, sekarang kita paksa 10.000 percobaan per detik.
    for (let i = 0; i < 3500; i++) { 
        
        // UBAH 2: PAKSA RUMUS PANJANG (KEDALAMAN 8 SAMPAI 12)
        // Matematika: Math.random() * 5 (0-4) + 8 = Hasilnya 8, 9, 10, 11, 12 komponen.
        let panjangRumus = Math.floor(Math.random() * 5) + 2; 
        
        let rumusKompleks = "";
        
        for (let j = 0; j < panjangRumus; j++) {
            let p = partsExtended[Math.floor(Math.random() * partsExtended.length)];
            let d = daysExtended[Math.floor(Math.random() * daysExtended.length)];
            let wrap = wrappers[Math.floor(Math.random() * wrappers.length)];
            let op = operators[Math.floor(Math.random() * operators.length)];

            // Biar terlihat makin canggih, kita perbanyak variasi Mistik/Index
            let unit = (wrap === '') ? `${p}${d}` : `${wrap}(${p}${d})`;

            if (j === 0) rumusKompleks += unit;
            else rumusKompleks += ` ${op} ${unit}`;
        }
        formulas.push(rumusKompleks);
    }
    return formulas;
}

// ==========================================================================
// 3. FUNGSI KONTROL
// ==========================================================================
function toggleAutoHunt() {
    let btn = document.getElementById('btnAuto');
    if (!isAutoRunning) {
        isAutoRunning = true;
        globalBestAcc = -1; 
        globalBestWinCount = 0;
        if(btn) { btn.innerText = "⛔ STOP AUTO HUNT"; btn.style.background = "#c0392b"; }
        mulaiScanOtomatis(); 
    } else {
        isAutoRunning = false;
        if(btn) { btn.innerText = "🤖 AUTO HUNT SAMPAI 100% (START)"; btn.style.background = "#e67e22"; }
        document.getElementById('status').innerText = "⏹️ Auto Hunt Dihentikan Manual.";
    }
}

function pilihStrategi(tipe) {
    currentStrategy = tipe; 
    let statusEl = document.getElementById('status');
    if(statusEl) {
        statusEl.innerText = "🔍 Mode: " + tipe + " (Mencari Rumus...)";
        statusEl.style.color = "#3498db";
    }
    if (!isAutoRunning) {
        globalBestAcc = -1; 
        globalBestWinCount = 0;
    }
    mulaiScanOtomatis();
}

// ==========================================================================
// 4. ENGINE UTAMA
// ==========================================================================
function mulaiScanOtomatis() {
    let statusEl = document.getElementById('status');
    if(statusEl) {
        statusEl.innerText = "🚀 SYSTEM WORKING: Mining & Testing Logika...";
        statusEl.style.color = "#e67e22";
    }

    if (!isAutoRunning) {
        globalBestAcc = -1; 
        globalBestWinCount = 0;
    }

    // TURBO MODE (10ms) - Agar pencarian sangat cepat
    setTimeout(() => { jalankanEngine(); }, 10); 
}

function jalankanEngine() {
    const rawData = document.getElementById('dataInput').value.trim().split('\n');
    const targetMode = document.getElementById('targetPos').value;
    const scanMode = document.getElementById('scanMode').value;
    
    let results = rawData.map(line => line.replace(/[^0-9]/g, '')).filter(x => x.length === 4);
    
    if (results.length < 15) {
        if (currentStrategy === 'EKSTRIM' && results.length < 30) {
            alert("⚠️ MODE EKSTRIM BUTUH MINIMAL 30 DATA!"); return;
        } else if (results.length < 15) {
            alert("⚠️ DATA KURANG! Masukkan minimal 15 result."); return;
        }
    }

    let patterns = generatePatterns(); 
    let bestScore = -1;
    let bestData = null;
    let outputType = getOutputType(targetMode);
    let startIdx = 10; 

    // --- LOOP SCANNING ---
    for (let formula of patterns) {
        
        // [BARU] FILTER ANTI-KEMBAR & AUTO SORTIR
        if (recentWinners.includes(formula)) continue; 

        // [LOGIKA SAKTI AUTO SORTIR]
        // Jika sedang mode sortir, kita harus pastikan prediksi rumus ini
        // BELUM ADA di daftar 'multiCollected' (Keranjang Angka Keras).
        if (isMultiRunning && formula) {
             let intipPrediksi = hitungRumus(formula, results, results.length, outputType);
             if (intipPrediksi) {
                 // Jika angkanya sudah ada di keranjang, SKIP! Cari rumus lain!
                 let valStr = intipPrediksi.digit.toString();
                 if (multiCollected.includes(valStr)) continue;
             }
        }
        
        let score = 0;
        let totalCheck = 0;
        let historyLog = [];

        for (let i = startIdx; i < results.length; i++) {
            let prediction = hitungRumus(formula, results, i, outputType);
            if (prediction === null) continue;
            let actualValue = getActualTarget(results[i], targetMode);
            let isWin = false;

            // --- LOGIKA AI HYBRID (URUT + ACAK OTOMATIS) ---
            if (targetMode.startsWith("AI_")) {
                let parts = targetMode.split('_'); 
                let aiCount = parseInt(parts[1]); 
                let aiSet = [];
                
                // DATA MATRIKS ACAK (Untuk Variasi)
                const MATRIK_JITU = [0, 7, 4, 1, 8, 5, 2, 9, 6, 3];
                
                // LOGIKA CERDAS:
                // Genap = Pakai Matrix (Acak), Ganjil = Pakai Urut (Sequential)
                let pakaiMatrix = (formula.length % 2 === 0);

                for(let k=0; k < aiCount; k++) { 
                    if (pakaiMatrix) {
                        // Mode Acak (Lompat)
                        let jumpVal = (prediction.digit + MATRIK_JITU[k]) % 10;
                        aiSet.push(jumpVal);
                    } else {
                        // Mode Urut (12345)
                        aiSet.push( (prediction.digit + k) % 10 );
                    }
                }
                isWin = aiSet.some(num => actualValue.includes(num.toString()));
            }
            else if (targetMode === 'CB_4D') {
                isWin = actualValue.includes(prediction.digit.toString());
            } 
            else {
                isWin = (prediction.digit === actualValue);
            }

            let isHit = (scanMode === 'ON') ? isWin : !isWin;
            if (isHit) score++;
            totalCheck++;
            historyLog.push({ idx: i, res: results[i], calc: prediction.calc, val: prediction.digit, win: isHit });
        }

        let accuracy = (totalCheck > 0) ? (score / totalCheck) * 100 : 0;
        
        if (totalCheck >= 5) {
            let len = historyLog.length;
            let last1 = (len >= 1) ? !historyLog[len-1].win : false; 
            let last2 = (len >= 2) ? !historyLog[len-2].win : false; 
            let last3 = (len >= 3) ? !historyLog[len-3].win : false; 

            let isNewChampion = false;

            // LOGIKA STRATEGI (NORMAL - MODIFIKASI: PEMBURU 100%)
            if (currentStrategy === 'NORMAL') {
                if (bestData === null) {
                    isNewChampion = true; // Data pertama selalu diterima dulu
                } else {
                    // TRIK PEMAKSA:
                    // 1. Jika Rumus Baru ini 100% (Hijau Semua), LANGSUNG PRIORITASKAN!
                    if (accuracy === 100) {
                        // Jika juara lama belum 100%, langsung tendang ganti yang baru.
                        if (bestData.acc < 100) {
                            isNewChampion = true;
                        } 
                        // Jika juara lama sudah 100% juga, adu panjang Win Streak-nya (Score)
                        else if (score >= bestData.winCount) {
                            isNewChampion = true;
                        }
                    }
                    // 2. Jika Rumus Baru TIDAK 100%, tapi juara lama juga jelek (di bawah 100)
                    // Maka ambil yang akurasinya lebih tinggi sebagai "cadangan"
                    else if (bestData.acc < 100 && accuracy > bestScore) {
                        isNewChampion = true;
                    }
                }
            }
            // --- REVISI FINAL: REBOUND "LONG DISTANCE" (H-60 BERSIH) ---
            else if (currentStrategy === 'REBOUND') {
                // 1. Cek Syarat Dasar: Akurasi Tinggi & Kemarin Zonk
                // Kita turunkan dikit syarat akurasi global ke 80% karena syarat H-60 itu sangat berat.
                let len = historyLog.length;
                let last1 = (len >= 1) ? !historyLog[len-1].win : false; 
                
                if (accuracy >= 80 && last1) {
                    // 2. LOGIKA BARU: CEK JARAK ZONK SEBELUMNYA
                    // Kita harus pastikan tidak ada Zonk (Kalah) dalam 60 hari ke belakang (H-2 s/d H-60)
                    
                    let isSafeGap = true;       // Asumsikan aman dulu
                    let minGap = 60;            // Jarak minimal zonk berikutnya (Request Bapak)
                    
                    // Loop mundur dari H-2 (index len-2)
                    for (let k = len - 2; k >= 0; k--) {
                        // Jika ketemu history yang kalah (Zonk)
                        if (!historyLog[k].win) {
                            let jarakHari = (len - 1) - k; // Hitung jarak dari H-1 ke Zonk itu
                            
                            // Jika jaraknya kurang dari 60 hari, berarti dia TIDAK STABIL
                            if (jarakHari < minGap) {
                                isSafeGap = false;
                            }
                            break; // Kita sudah nemu zonk terdekat, stop looping.
                        }
                    }

                    // 3. EKSEKUSI JIKA LOLOS JARAK AMAN
                    if (isSafeGap) {
                        if (bestData === null) isNewChampion = true;
                        else {
                            // Prioritaskan yang baru ini karena dia lolos filter berat H-60
                            let bestLast1 = (bestData.hist.length >= 1) ? !bestData.hist[bestData.hist.length-1].win : false;
                            
                            // Logika prioritas standar
                            if (!bestLast1) isNewChampion = true; 
                            else if (accuracy > bestScore) isNewChampion = true;
                        }
                    }
                }
            }
            
            if (isNewChampion) {
                bestScore = accuracy;
                bestData = { formula: formula, acc: accuracy, hist: historyLog, winCount: score, total: totalCheck };
            }
        }
    }

    if (bestData) {
        if (bestData.acc > globalBestAcc) {
             globalBestAcc = bestData.acc;
             globalBestWinCount = bestData.winCount;
        }
        tampilkanHasil(bestData, results, outputType, targetMode, scanMode);
    }

    let statusEl = document.getElementById('status');
    
    // --- LOGIKA MENANGKAP JACKPOT (MODIFIKASI AUTO SORTIR) ---
    if (isAutoRunning && bestData && bestData.acc === 100 && bestData.total >= 10) {
        
        // JIKA SEDANG MODE AUTO SORTIR
        if (isMultiRunning) {
            // Ambil prediksi masa depan
            let nextP = hitungRumus(bestData.formula, results, results.length, outputType);
            let val = nextP.digit.toString();

            // Masukkan ke keranjang 'Keras'
            if (!multiCollected.includes(val)) {
                multiCollected.push(val);
                // Masukkan rumus ke blacklist agar tidak dipakai lagi
                recentWinners.push(bestData.formula);
            }

            // Update Status di Layar
            let targetName = multiTargetQueue[currentMultiIdx];
            
            // --- LOGIKA DINAMIS SISA TARGET (MODIFIKASI USER) ---
            // 1. Ambil kemauan user (mau sisa berapa?)
            let inputSisa = document.getElementById('targetSisa');
            let wantSisa = inputSisa ? parseInt(inputSisa.value) : 2; 
            if (isNaN(wantSisa) || wantSisa < 1) wantSisa = 2; // Safety Default

            // 2. Tentukan Total Semesta (Shio=12, Jumlah=9, Digit=10)
            let totalSemesta = 10; // Default Digit (0-9)
            
            if (targetName.startsWith("SHIO")) {
                totalSemesta = 12; // Shio ada 12
            } else if (targetName.startsWith("JML")) {
                totalSemesta = 9;  // Jumlah cuma 1-9 (0 dibuang sesuai request)
            }
            
            // 3. Hitung target kumpul (Total - Sisa)
            // Contoh: Digit (10) - Mau Sisa (1) = Harus Kumpul 9
            let maxCollect = totalSemesta - wantSisa;

            // Safety: Jangan sampai minus (misal user minta sisa 15 padahal digit cuma 10)
            if (maxCollect < 1) maxCollect = totalSemesta - 1;
            
            document.getElementById('multiStatus').innerText = `♻️ Sedang Sortir ${targetName}... Dapat: ${multiCollected.length} / ${maxCollect} (Angka: ${val})`;

            // CEK APAKAH SUDAH TERKUMPUL SESUAI TARGET? (SISAKAN 2)
            if (multiCollected.length >= maxCollect) {
                // SELESAI SATU TARGET, HITUNG BOM (SISA 2)
                simpanHasilSortir(targetName, outputType);
                
                // Pindah ke target berikutnya
                currentMultiIdx++;
                if (currentMultiIdx < multiTargetQueue.length) {
                    // Reset untuk target baru
                    setupNextTarget();
                } else {
    // SEMUA TARGET SELESAI!
    isAutoRunning = false;
    isMultiRunning = false;
    document.getElementById('multiStatus').innerText = "✅ SEMUA SELESAI! SILAKAN CEK TABEL.";
    document.getElementById('btnMulti').innerText = "🚀 MULAI SORTIR OTOMATIS";
    
    // --- GENERATE ANGKA JADI SEKARANG (INI YANG KURANG) ---
    generateAngkaJadi(); 

    // --- TAMBAHAN KIKI: BUNYIKAN ALARM KEMENANGAN ---
    let winSound = new Audio("https://actions.google.com/sounds/v1/cartoon/clown_horn.ogg"); // Suara Terompet
    winSound.play().catch(e => console.log("Gagal memutar suara: ", e));
    
    // Ambil angka yang dimau user dari HTML
let sisaMau = document.getElementById('targetSisa') ? document.getElementById('targetSisa').value : "2";

setTimeout(() => {
    alert(`🎉 PROSES SORTIR SELESAI! SISA ${sisaMau} LINE SIAP.`);
}, 500);
}
            } else {
                // Belum cukup, lanjut cari angka berikutnya
                setTimeout(() => { jalankanEngine(); }, 10);
            }
            return; // Keluar agar tidak memicu alert jackpot biasa
        }

        // JIKA MODE BIASA (BUKAN AUTO SORTIR) - PERILAKU SEPERTI DULU
        isAutoRunning = false;
        if(statusEl) statusEl.innerText = "🎉 JACKPOT DITEMUKAN!";
        let btn = document.getElementById('btnAuto');
        if(btn) { btn.innerText = "🤖 AUTO HUNT SELESAI"; btn.style.background = "#27ae60"; }
        tampilkanHasil(bestData, results, outputType, targetMode, scanMode);
        setTimeout(() => { alert(`JACKPOT 100% DITEMUKAN!`); }, 500); 
        return;
    }

    if (isAutoRunning) {
        if(statusEl) statusEl.innerText = `🔄 Mining (${currentStrategy})... Top: ${globalBestAcc.toFixed(1)}%`;
        setTimeout(() => { jalankanEngine(); }, 10); 
    } else {
        if(statusEl) {
            statusEl.innerText = `✅ Selesai Mode: ${currentStrategy}`;
            statusEl.style.color = "green";
        }
    }
}

// ==========================================================================
// 5. RENDER UI
// ==========================================================================
function tampilkanHasil(data, results, outputType, targetMode, scanMode) {
    if (!data) return;
    
    // [BARU] MASUKKAN RUMUS JUARA KE DAFTAR HITAM (AGAR TIDAK MUNCUL LAGI SEGERA)
    recentWinners.push(data.formula);
    
    // Jaga agar ingatan tidak terlalu penuh (Cukup ingat 5 terakhir)
    if (recentWinners.length > MAX_MEMORY) {
        recentWinners.shift(); // Hapus yang paling lama (FIFO - First In First Out)
    }
    
    document.getElementById('resultArea').style.display = 'block';
    document.getElementById('bestFormula').innerText = data.formula;
    
    let accElem = document.getElementById('bestAcc');
    accElem.innerText = data.acc.toFixed(1) + "%";
    accElem.style.color = (data.acc === 100) ? "#00ff00" : (data.acc > 80) ? "#ffff00" : "#ff0000";

    document.getElementById('bestWin').innerText = data.winCount + "/" + data.total;

    let nextPred = hitungRumus(data.formula, results, results.length, outputType);
    let labelNext = "?";
    
    if (nextPred) {
        if (targetMode.startsWith("AI_")) {
             let parts = targetMode.split('_'); 
             let aiCount = parseInt(parts[1]); 
             let aiSet = [];
             
             // DEFINISI MATRIKS SAMA PERSIS DENGAN ENGINE
             const MATRIK_JITU = [0, 7, 4, 1, 8, 5, 2, 9, 6, 3];
             let pakaiMatrix = (data.formula.length % 2 === 0);

             for(let k=0; k < aiCount; k++) { 
                 if (pakaiMatrix) {
                     let jumpVal = (nextPred.digit + MATRIK_JITU[k]) % 10;
                     aiSet.push(jumpVal);
                 } else {
                     aiSet.push( (nextPred.digit + k) % 10 );
                 }
             }
             labelNext = aiSet.join(", ");
        } else {
             labelNext = formatOutput(nextPred.digit, targetMode);
        }
    }
    document.getElementById('nextPred').innerText = labelNext;

// [BARU] LOGIKA ALARM
    if (isVotingActive) {
        updateVotingLogic(labelNext);
    }

    let tbody = document.querySelector("#historyTable tbody");
    tbody.innerHTML = "";
    tbody.innerHTML += `<tr class="future"><td>NEXT</td><td>????</td><td>Rumus</td><td>${labelNext}</td><td>PREDIKSI</td></tr>`;

    let displayHist = data.hist.slice().reverse(); 
    for (let h of displayHist) {
        let status = "";
        if (scanMode === 'ON') status = h.win ? "<b class='win'>JITU ✅</b>" : "<span class='lose'>ZONK ❌</span>";
        else status = h.win ? "<b class='win'>JITU (MATI) ✅</b>" : "<span class='lose'>JEBOL ❌</span>";

        let displayVal = formatOutput(h.val, targetMode);
        if (targetMode.startsWith("AI_")) {
             let parts = targetMode.split('_'); 
             let aiCount = parseInt(parts[1]); 
             let aiSet = [];
             
             const MATRIK_JITU = [0, 7, 4, 1, 8, 5, 2, 9, 6, 3];
             let pakaiMatrix = (data.formula.length % 2 === 0);

             for(let k=0; k < aiCount; k++) { 
                 if (pakaiMatrix) {
                     let jumpVal = (h.val + MATRIK_JITU[k]) % 10;
                     aiSet.push(jumpVal);
                 } else {
                     aiSet.push( (h.val + k) % 10 );
                 }
             }
             displayVal = aiSet.join(", ");
        }

        let hariKe = results.length - h.idx;
        tbody.innerHTML += `<tr><td>H-${hariKe}</td><td>${h.res}</td><td><small>calc</small></td><td><b>${displayVal}</b></td><td>${status}</td></tr>`;
    }
}

// ==========================================================================
// 6. HELPER LOGIC & MATH
// ==========================================================================
function getOutputType(mode) {
    if (mode.startsWith("SHIO")) return 'SHIO'; 
    if (mode.startsWith("GG") || mode.startsWith("BK")) return 'BINARY'; 
    if (mode.startsWith("JML")) return 'SUM';
    return 'DIGIT'; 
}

// --- [BARU] FUNGSI CEK INDEKS (MIRROR BLOCK) ---
// Logika: Memastikan angka OFF benar-benar mati dimakan Indeks Result Lalu
function cekIndeksMati(targetAngka, resultTerakhir) {
    const mapIndeks = {
        0: 5, 1: 6, 2: 7, 3: 8, 4: 9,
        5: 0, 6: 1, 7: 2, 8: 3, 9: 4
    };
    // Ambil Ekor Terakhir (Digit paling belakang)
    let ekorTerakhir = parseInt(resultTerakhir.toString().slice(-1));
    if (isNaN(ekorTerakhir)) return false; // Validasi data
    
    let musuh = mapIndeks[ekorTerakhir];
    
    // Jika Target sama dengan Musuh (Indeks), berarti VALID MATI (Aman)
    return (parseInt(targetAngka) === musuh);
}

function getActualTarget(res, mode) {
    let A = parseInt(res[0]), C = parseInt(res[1]), K = parseInt(res[2]), E = parseInt(res[3]);
    
    // FIX COLOK BEBAS 4D
    if (mode === 'CB_4D') return res; 

    if (mode === 'AS') return A;
    if (mode === 'COP') return C;
    if (mode === 'KEP') return K;
    if (mode === 'EKOR') return E;
    
    if (mode === 'JML_2D_DP') return (A+C)%9 || 9;
    if (mode === 'JML_2D_TH') return (C+K)%9 || 9;
    if (mode === 'JML_2D_BL') return (K+E)%9 || 9;

    if (mode.startsWith('AI_')) {
        if (mode.endsWith('_DP')) return res.substring(0, 2);
        if (mode.endsWith('_TH')) return res.substring(1, 3);
        if (mode.endsWith('_BL')) return res.substring(2, 4);
    }
    if (mode.startsWith('SHIO')) {
        let valStr = (mode==='SHIO_DP') ? res.substring(0,2) : (mode==='SHIO_TH') ? res.substring(1,3) : res.substring(2,4);
        return getShioFrom2D(parseInt(valStr));
    }
    if (mode.startsWith('GG')) { let val=(mode==='GG_AS')?A:(mode==='GG_COP')?C:(mode==='GG_KEP')?K:E; return val%2; }
    if (mode.startsWith('BK')) { let val=(mode==='BK_AS')?A:(mode==='BK_COP')?C:(mode==='BK_KEP')?K:E; return (val>=5)?1:0; }
    return 0;
}

function hitungRumus(formula, results, idx, type) {
    let parsed = formula.replace(/([ACKE])([0-9]+)/g, (match, t, l) => {
        let stepBack = parseInt(l); 
        let dataIdx = idx - stepBack;
        if (dataIdx < 0 || !results[dataIdx]) return 'NULL';
        
        let r = results[dataIdx];
        if (t === 'A') return r[0]; if (t === 'C') return r[1];
        if (t === 'K') return r[2]; if (t === 'E') return r[3];
        return '0';
    });

    if (parsed.includes('NULL')) return null;

    parsed = parsed.replace(/ML\((\d+)\)/g, (m, n) => MISTIK_LAMA[parseInt(n)] || 0);
    parsed = parsed.replace(/MB\((\d+)\)/g, (m, n) => MISTIK_BARU[parseInt(n)] || 0);
    parsed = parsed.replace(/IDX\((\d+)\)/g, (m, n) => INDEX_DATA[parseInt(n)] || 0);
    parsed = parsed.replace(/TYS\((\d+)\)/g, (m, n) => TAYSEN_DATA[parseInt(n)] || 0);

    let res = 0;
    try { 
        res = eval(parsed); 
    } catch { return null; }

    if (isNaN(res) || !isFinite(res)) res = 0;
    
    let n = Math.abs(Math.round(res));
    let digit = 0;

    if (type === 'SHIO') { 
        if (n === 0) digit = 12; 
        else { let rem = n % 12; digit = (rem === 0) ? 12 : rem; } 
    } 
    else if (type === 'BINARY') { digit = n % 2; } 
    else if (type === 'SUM') { digit = (n % 9) || 9; }
    else { digit = n % 10; }

    return { calc: formula, digit: digit };
}

function getShioFrom2D(num) {
    if (isNaN(num)) return 0;
    for (let s in SHIO_DATA) { if (SHIO_DATA[s].includes(num)) return parseInt(s); }
    return 0; 
}

function formatOutput(val, mode) {
    if (mode.startsWith("SHIO")) return "Shio " + val;
    if (mode.startsWith("GG")) return (val === 1) ? "GANJIL" : "GENAP";
    if (mode.startsWith("BK")) return (val === 1) ? "BESAR" : "KECIL";
    return val;
}

// ==========================================================================
// 7. SALIN LAPORAN
// ==========================================================================
function salinLaporan() {
    let resultArea = document.getElementById('resultArea');
    if (resultArea.style.display === 'none') {
        alert("Belum ada hasil scan!");
        return;
    }

    let rumus = document.getElementById('bestFormula').innerText;
    let akurasi = document.getElementById('bestAcc').innerText;
    let menang = document.getElementById('bestWin').innerText;
    let next = document.getElementById('nextPred').innerText;
    
    let text = "🔎 *LAPORAN ANALISA* 🔎\n";
    text += "==================================\n";
    text += "📊 RUMUS: " + rumus + "\n";
    text += "🎯 AKURASI: " + akurasi + "\n";
    text += "✅ REKAM JEJAK: " + menang + "\n";
    text += "🔮 *NEXT PREDIKSI: " + next + "*\n";
    text += "==================================\n";
    text += "📜 *HISTORY SCAN:*\n";

    let rows = document.querySelectorAll("#historyTable tbody tr");
    rows.forEach(row => {
        let cols = row.querySelectorAll("td");
        if (cols.length > 0) {
            let periode = cols[0].innerText;
            if(periode !== "NEXT" && periode !== "MASA DEPAN") {
                let result = cols[1].innerText;
                let hasil = cols[3].innerText;
                let status = cols[4].innerText;
                status = status.replace("✅", "").replace("❌", "").trim();
                text += `[${periode}] Res:${result} -> ${hasil} (${status})\n`;
            }
        }
    });
    text += "==================================\nPrediksi Angka Togel Berdasarkan Data.\nFormula by Kiki";
    navigator.clipboard.writeText(text).then(() => { alert("✅ Laporan Tersalin!"); });
}

// ==========================================================================
// 8. FITUR AUTO VOTING & ALARM (SYSTEM PENGGANTI EKSTRIM)
// ==========================================================================
function toggleVotingMode() {
    let btn = document.getElementById('btnVoting');
    
    if (!isVotingActive) {
        // --- START VOTING ---
        isVotingActive = true;
        votingData = {}; 
        
        btn.innerText = "🔊 STOP ALARM";
        btn.style.background = "#27ae60"; 
        document.getElementById('voteStatus').innerText = "🔴 Mendengarkan Hasil Scan...";
        
        // Otomatis nyalakan mesin jika belum nyala
        if (!isAutoRunning) toggleAutoHunt(); 
        
    } else {
        // --- STOP VOTING ---
        isVotingActive = false;
        alarmSound.pause();
        alarmSound.currentTime = 0; 
        
        btn.innerText = "🔇 START ALARM";
        btn.style.background = "#e74c3c"; 
        document.getElementById('voteStatus').innerText = "⏹️ Voting Berhenti.";
        
        if (isAutoRunning) toggleAutoHunt(); 
    }
}

function updateVotingLogic(prediksiAngka) {
    if (!isVotingActive) return;

    // Bersihkan data angka (ambil angkanya saja jika ada teks)
    // Contoh: "Shio 5" -> "5", "GANJIL" -> "GANJIL"
    let key = prediksiAngka.toString().replace("Shio ", "").trim();
    
    if (!votingData[key]) votingData[key] = 0;
    votingData[key]++;

    // Urutkan suara terbanyak
    let sortedVotes = Object.entries(votingData).sort((a, b) => b[1] - a[1]); 
    
    // Tampilkan di layar panel hitam
    let statusText = sortedVotes.slice(0, 3).map(v => `${v[0]}:(${v[1]})`).join(" | ");
    document.getElementById('voteStatus').innerText = "📊 " + statusText;

    // LOGIKA BUNYI ALARM (GAP / DOMINASI)
    let targetGap = parseInt(document.getElementById('targetGap').value) || 4;

    if (sortedVotes.length >= 2) {
        let juara1 = sortedVotes[0];
        let juara2 = sortedVotes[1];
        
        // Jika selisih suara >= Target Gap, BUNYIKAN!
        if ((juara1[1] - juara2[1]) >= targetGap) {
            bunyikanAlarm(juara1[0], juara1[1], targetGap);
        }
    } 
    // Jika calon tunggal (musuh nol) dan suara sudah 5+
    else if (sortedVotes.length === 1 && sortedVotes[0][1] >= targetGap + 1) {
         bunyikanAlarm(sortedVotes[0][0], sortedVotes[0][1], targetGap);
    }
}

function bunyikanAlarm(pemenang, suara, gap) {
    // Matikan scan otomatis biar HP gak panas, tapi Alarm tetap bunyi
    if (isAutoRunning) toggleAutoHunt();
    
    alarmSound.play().catch(e => console.log("Audio Error: ", e));
    
    // Tampilkan Notifikasi
    alert(`🔔 DING DONG! DOMINASI MUTLAK!\n\nAngka Pemenang: [ ${pemenang} ]\nTotal Suara: ${suara}\nSelisih Gap: ${gap}\n\nSILAHKAN PASANG SEKARANG!`);
}

// ==========================================================================
// 9. LOGIKA AUTO SORTIR (NYICIL FITUR)
// ==========================================================================
function startMultiScan() {
    let inputRaw = document.getElementById('multiTargetInput').value;
    if(!inputRaw) { alert("Isi dulu targetnya! Contoh: KEP, EKOR"); return; }
    
    // Bersihkan input user
    multiTargetQueue = inputRaw.split(',').map(s => s.trim().toUpperCase()).filter(s => s !== "");
    
    if(multiTargetQueue.length === 0) return;

// --- RESET MEMORI LAMA (AGAR TIDAK CAMPUR ADUK) ---
    finalRekapData = {}; 
    let areaAngka = document.getElementById('areaAngkaJadi');
    if(areaAngka) areaAngka.style.display = 'none';

    // Reset Variabel
    isMultiRunning = true;
    currentMultiIdx = 0;
    multiResults = [];
    document.getElementById('multiResultBody').innerHTML = ""; // Bersihkan tabel
    document.getElementById('multiResultArea').style.display = 'block';
    
    // Ubah tombol jadi loading
    let btn = document.getElementById('btnMulti');
    if(btn) btn.innerText = "⏳ SEDANG MEMPROSES...";
    
    setupNextTarget();
}

function stopMultiScan() {
    isMultiRunning = false;
    isAutoRunning = false;
    document.getElementById('multiStatus').innerText = "⏹️ Dihentikan Manual.";
    let btn = document.getElementById('btnMulti');
    if(btn) btn.innerText = "🚀 MULAI SORTIR OTOMATIS";

  // --- GENERATE ANGKA JADI SEKARANG ---
    generateAngkaJadi();
}

function setupNextTarget() {
    // Ambil target saat ini (misal KEP)
    let target = multiTargetQueue[currentMultiIdx];
    
    // Ganti settingan dropdown HTML secara otomatis
    let drop = document.getElementById('targetPos');
    let found = false;
    // Cari opsi di dropdown yang value-nya cocok
    for(let i=0; i<drop.options.length; i++){
        if(drop.options[i].value === target) {
            drop.selectedIndex = i;
            found = true;
            break;
        }
    }
    
    if(!found) {
        alert("Kode Target Tidak Dikenal: " + target + "\nGunakan kode yang benar (KEP, EKOR, AS, dll)");
        stopMultiScan();
        return;
    }

    // Reset penampung angka
    multiCollected = [];
    document.getElementById('multiStatus').innerText = `🔄 Memulai Analisa ${target}...`;
    
    // Jalankan Mesin
    isAutoRunning = true; 
    mulaiScanOtomatis();
}

function simpanHasilSortir(targetName, type) {
    // 1. Tentukan Semesta Angka (0-9 atau 1-12 Shio)
    let allCandidates = [];
    if (type === 'SHIO') {
        allCandidates = ["1","2","3","4","5","6","7","8","9","10","11","12"];
    } else if (type === 'SUM') {
        // Asumsi jumlah 1-9 (sesuai logika lama)
        allCandidates = ["1","2","3","4","5","6","7","8","9"];
    } else {
        // Digit 0-9
        allCandidates = ["0","1","2","3","4","5","6","7","8","9"];
    }

    // 2. Cari Sisa (BOM)
    // Sisa adalah yang TIDAK ada di multiCollected (Angka yang belum dapet rumus keras)
    let bom = allCandidates.filter(x => !multiCollected.includes(x));
    
    // SIMPAN DATA KE MEMORI UNTUK DIGABUNG NANTI
    finalRekapData[targetName] = bom;
    // 3. Render ke Tabel
    let tbody = document.getElementById('multiResultBody');
    
    // Gabungkan angka keras yang terkumpul
    let kerasStr = multiCollected.sort((a,b)=>a-b).join(', ');
    let bomStr = bom.join(', ');

    let row = `
        <tr style="border-bottom:1px solid #444;">
            <td style="font-weight:bold; color:#00d2d3;">${targetName}</td>
            <td style="color:#aaa; word-break:break-all;">${kerasStr}</td>
            <td style="font-weight:bold; font-size:1.1rem; color:yellow; background:#222;">${bomStr}</td>
        </tr>
    `;
    tbody.innerHTML += row;
}

// ==========================================================================
// 10. GENERATOR ANGKA JADI (LOGIKA TERBALIK: SISA ADALAH ANGKA MATI/OFF)
// ==========================================================================
function generateAngkaJadi() {
    let outputEl = document.getElementById('outputRekap');
    let areaEl = document.getElementById('areaAngkaJadi');
    
    // 1. SIAPKAN SEMESTA ANGKA 2D (00 - 99)
    let angkaJadi = [];
    for (let i = 0; i < 100; i++) {
        angkaJadi.push(i.toString().padStart(2, '0'));
    }

    // 2. LOGIKA FILTER (MEMBUANG ANGKA SISA)
    // Tanda '!' artinya TIDAK BOLEH ADA (Membuang angka sisa)

    // --- A. FILTER POSISI DASAR (KEPALA & EKOR) ---
    if (finalRekapData['KEP']) {
        let bomKep = finalRekapData['KEP']; 
        // Buang angka yang kepalanya ada di Sisa
        angkaJadi = angkaJadi.filter(line => !bomKep.includes(line[0]));
    }
    
    if (finalRekapData['EKOR']) {
        let bomEkor = finalRekapData['EKOR']; 
        // Buang angka yang ekornya ada di Sisa
        angkaJadi = angkaJadi.filter(line => !bomEkor.includes(line[1]));
    }

    // --- B. FILTER JUMLAH (JML_2D_BL) ---
    if (finalRekapData['JML_2D_BL']) {
        let bomJml = finalRekapData['JML_2D_BL'];
        angkaJadi = angkaJadi.filter(line => {
            let k = parseInt(line[0]);
            let e = parseInt(line[1]);
            let jml = (k + e) % 9 || 9; 
            // Buang angka yang jumlahnya ada di Sisa
            return !bomJml.includes(jml.toString());
        });
    }

    // --- C. FILTER SHIO (SHIO_BL) ---
    if (finalRekapData['SHIO_BL']) {
        let bomShio = finalRekapData['SHIO_BL'];
        angkaJadi = angkaJadi.filter(line => {
            let val = parseInt(line);
            let shioFound = getShioFrom2D(val); 
            // Buang angka yang shionya ada di Sisa
            return !bomShio.includes(shioFound.toString());
        });
    }

    // --- D. FILTER ANGKA IKUT (AI_BELAKANG) ---
    // Jika AI Sisa adalah AI Mati, maka digit tersebut TIDAK BOLEH muncul
    for (let key in finalRekapData) {
        if (key.startsWith("AI_") && key.endsWith("_BL")) {
            let bomAI = finalRekapData[key];
            angkaJadi = angkaJadi.filter(line => {
                // Pastikan digit Kepala DAN Ekor TIDAK ADA di daftar AI Sisa
                return !bomAI.includes(line[0]) && !bomAI.includes(line[1]);
            });
        }
    }

    // --- E. FILTER GANJIL/GENAP & BESAR/KECIL (EKOR) ---
    if (finalRekapData['GG_EKOR']) {
        let bomGG = finalRekapData['GG_EKOR']; 
        angkaJadi = angkaJadi.filter(line => {
            let e = parseInt(line[1]);
            let status = (e % 2 !== 0) ? "GANJIL" : "GENAP";
            return !bomGG.includes(status);
        });
    }
    
    if (finalRekapData['BK_EKOR']) {
        let bomBK = finalRekapData['BK_EKOR']; 
        angkaJadi = angkaJadi.filter(line => {
            let e = parseInt(line[1]);
            let status = (e >= 5) ? "BESAR" : "KECIL";
            return !bomBK.includes(status);
        });
    }

    // 3. TAMPILKAN HASIL AKHIR (PAKSA MUNCUL)
    if(areaEl) areaEl.style.display = 'block'; 

    if (angkaJadi.length > 0) {
        let labelInfo = document.querySelector("#areaAngkaJadi label");
        if(labelInfo) labelInfo.innerHTML = `✅ ANGKA JADI (${angkaJadi.length} LINE):`;
        if(outputEl) outputEl.value = angkaJadi.join("*");
    } else {
        let labelInfo = document.querySelector("#areaAngkaJadi label");
        if(labelInfo) labelInfo.innerHTML = `❌ ZONK (0 LINE):`;
        if(outputEl) outputEl.value = "Semua angka mati terbuang habis! Coba kurangi target filter.";
    }
}

// ==========================================================================
// FUNGSI SALIN ANTI-GAGAL (JURUS PAKSA)
// ==========================================================================
function copyRekap() {
    let copyText = document.getElementById("outputRekap");
    
    if (!copyText || copyText.value === "") {
        alert("❌ Tidak ada data untuk disalin!");
        return;
    }

    // 1. Pilih Teksnya (Wajib untuk HP)
    copyText.select();
    copyText.setSelectionRange(0, 99999); 

    // 2. Coba Cara Modern dulu
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(copyText.value)
            .then(() => { alert("✅ Angka Invest Berhasil Disalin!"); })
            .catch(err => {
                // Kalau Modern Gagal, Pakai Jurus Lama
                fallbackCopy(copyText);
            });
    } else {
        // Kalau Browser Jadul/Acode, Langsung Jurus Lama
        fallbackCopy(copyText);
    }
}

function fallbackCopy(textElement) {
    try {
        // Jurus Lama: document.execCommand (Lebih Sakti di Localhost/HP)
        let successful = document.execCommand('copy');
        if (successful) {
            alert("✅ Angka Invest Berhasil Disalin! (Mode Klasik)");
        } else {
            alert("❌ Gagal Salin. Silakan tekan lama pada kotak lalu pilih 'Salin'.");
        }
    } catch (err) {
        alert("❌ Error Browser. Salin manual saja.");
    }
}